<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<html>
<head>

		<title>Is Painting Therapy the same as Art Therapy?</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	
	    <link href="ldc.css" rel="stylesheet" type="text/css">
	    <script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
</head>								
	<body leftmargin=0 topmargin=0 rightmargin=0 bottommargin=0 onLoad="MM_preloadImages('images/lianne.jpg','images/articles_2.jpg','images/reflections_2.jpg','images/education_2.jpg','images/therapy_2.jpg','images/contact_2.jpg')">
	<table cellspacing=0 cellpadding=0 width=100% height=100% border=0>

        <tr height=75>
          <td bgcolor=#403d3c>&nbsp;</td>
          <td width=230 bgcolor=#403d3c>&nbsp;</td>
          <td width=478>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr height=570>   
          <td bgcolor=403d3c>&nbsp;</td>
          <td colspan=2 valign=top height=570>



             <table width=708 height=570 border=0 align=center cellpadding=0 cellspacing=0 bordercolor="#000000" class="border">
             <tr>
               <td width=708 valign=top bordercolor="#000000" class="body_text"><table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
                 <tr>
                   <td colspan="6"><div align="center"><a href="http://www.lightdarknessandcolor.org/home.php"><img src="images/banner.jpg" alt="Light, Darkness &amp; Color" width="688" height="110" border="0"></a></div></td>
                 </tr>
                 <tr>
                   <td><a href="/liane.php" target="_top" onClick="MM_nbGroup('down','group1','lianne1','',1)" onMouseOver="MM_nbGroup('over','lianne1','images/lianne.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/lianne_1.jpg" alt="Lianne Collot d'Herbois" name="lianne1" width="98" height="55" border="0"></a></td>
                   <td><a href="/articles.php" target="_top" onClick="MM_nbGroup('down','group1','articles1','',1)" onMouseOver="MM_nbGroup('over','articles1','images/articles_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/articles_1.jpg" alt="Articles" name="articles1" width="98" height="55" border="0"></a></td>
                   <td><a href="/reflections.php" target="_top" onClick="MM_nbGroup('down','group1','reflections1','',1)" onMouseOver="MM_nbGroup('over','reflections1','images/reflections_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/reflections_1.jpg" alt="Personal Reflections" name="reflections1" width="98" height="55" border="0"></a></td>
                   <td><a href="/education.php" target="_top" onClick="MM_nbGroup('down','group1','education1','',1)" onMouseOver="MM_nbGroup('over','education1','images/education_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/education_1.jpg" name="education1" width="98" height="55" border="0"></a></td>
                   <td><a href="/therapy.php" target="_top" onClick="MM_nbGroup('down','group1','therapy1','',1)" onMouseOver="MM_nbGroup('over','therapy1','images/therapy_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/therapy_1.jpg" alt="Painting Therapy" name="therapy1" width="98" height="55" border="0"></a></td>
                   <td><a href="/contact.php" target="_top" onClick="MM_nbGroup('down','group1','contact1','',1)" onMouseOver="MM_nbGroup('over','contact1','images/contact_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/contact_1.jpg" alt="Contact" name="contact1" width="98" height="55" border="0"></a></td>
                 </tr>
                 <tr>
                   <td colspan="6" class="body_text"><h1><strong>Is Painting Therapy the Same as Art Therapy?</strong></h1>
                     </strong>&copy;Pamela Whitman 2007
                     <p>Though we use the tools and media of the visual arts, there is an important difference between Painting Therapy and traditional art therapy. We go beyond the level of the expressive or symbolic content of art, viewing it from an even deeper level than the intended meanings or interpretations. We look at the client through the laws of Light, Darkness and Color that stand behind what is expressed, which can then reveal the direct connection to the human being on all levels. Diagnostic information is obtained from &ldquo;free pictures&rdquo; that reveal the characteristics of the archetypal interactions of light, darkness and color, based on the laws of how they manifest in the atmosphere and are reflected in the human being. In this way, we go beyond individual subjective expression and call upon the universal creative principles from which our individual creativity springs.</p>
                     <p>Looking at pictures from this perspective reveals the qualities of disease processes, the tendencies for illness, and blocks on the path of incarnation. The real potential of this therapy lies in its ability to address the deeper levels in the human being through the power of the individual&rsquo;s spirit, thereby affecting change on all levels, including the physical.</p>
                     <p>Painting Therapy spans the relationship between body, soul and spirit. It is groundbreaking work that provides a new paradigm for healing, distinguished from art therapy. Where traditional art therapy, at least in the United States, may be prescribed for emotional or psychological issues, Painting Therapy based on the method of Collot d&rsquo;Herbois is prescribed (in Europe) for the full range of conditions, from psychological to physical, both preventively and therapeutically. This innovative approach is proving its effectiveness as a pioneering medical painting therapy.</p>
                     <p>&nbsp;</p>
                     <h2><strong>Regarding Painting Therapy as a Medical Therapy </strong><br>
                       &copy;Pamela Whitman 2007</h2>
                     <p>Working out of the laws of Light and Darkness as the origin of Color makes it possible to work therapeutically within the <em>whole</em> human being. Painting Therapy not only works on the rhythmic, moving connection between the astral and etheric bodies, it also affects how the ego works into all the sheaths, right down to the physical. The spiritual aspects of Light and Darkness give impulse to our working in the physical world. The &ldquo;path of incarnation&rdquo; of the ego from above, through the light in connection with thinking in relation to the nerve-sense system, and from below, through the darkness connected to the will in relation to the metabolic system, can be made more clear and direct in this therapy, obstacles can be removed and a space can be created for the spirit. Then the ego can assume its proper role as the director of the human organism and the natural healing processes are catalyzed. </p>
                     <blockquote>
                       <blockquote>
                         <p>The light brings us into incarnation and the darkness provides the vessel for incarnation through warmth, will and the connection with the earth itself. This connection is essential, for without it there would be no possibility of transformation and, therefore, no coming to materialization. So it is through the forces of light and darkness that we are able to incarnate and have a connection with the earth and thereby can become healed (Collot d&rsquo;Herbois, May 1995).</p>
                       </blockquote>
                     </blockquote>
                     <p>Collot d&rsquo;Herbois was the first to apply the important spiritual principle of reversal of the spiritual world into the physical world to painting therapy. Through her deep understanding of the nature of the origin of color in connection to the human being, her approach to Painting Therapy truly stands in a field of its own, utilizing the path of consciousness (light) and the path of life (darkness) as the basis for a medical therapy for the whole human being, based on universal human principles and working across all cultures. Healing takes place through the activity of the ego working from above through the path of light and from below through the path of darkness.</p>
                     <p>Anthroposophical therapies include both approaches, and each has its value. Therapies that address the needs of the soul have a more hygienic character and use more illustrative techniques, based on stories or images of the outer world (Hauschka, 1985). The emphasis is not so much on expressing oneself, as it might be in more traditional art therapy, but on living into the qualities of color and form as expressed in the theme (Mees-Christeller, 1985). This approach can be healing in a general way with a hygienic character. It can help the soul breathe out, raise our mood and give a feeling of connection, qualities sorely needed in our world today. It provides what Collot d&rsquo;Herbois sometimes referred to as an &ldquo;oiling of the soul.&rdquo;</p>
                     <p>However, if we are to use color as a medicine in order to make progress as human beings, we must not limit ourselves only to the realm of feelings (Collot d&rsquo;Herbois, May 1995, October 1997). If we paint the outer world without a reversal, we stay in a soul picture, in a closed world. We cannot make the bridge to the world of spirit and the healing forces of Light and Darkness if the ego is not really called upon. </p>
                     <blockquote>
                       <blockquote>
                         <p>Therapies that restrict themselves to the confines of the individual soul can help resolve a neurosis, but if they do not call on the patient&rsquo;s ego and thereby help initiate a period of personal development, they can have no lasting effect. Nor can they truly heal(Treichler, 1989, p. 334).</p>
                       </blockquote>
                     </blockquote>
                     <p>Color relates to the world of feeling through our dream-like consciousness.&nbsp; It connects to our soul moods, which are changing continuously. Light and darkness, being spiritual qualities, are not so touched by the happenings of the soul, and therefore can provide a more exact basis for diagnosis (Collot d&rsquo;Herbois, October 1994, October 1997). When we want to reach the <em>individual,</em> we must include light and darkness, since this relates to the individual&rsquo;s path of incarnation. Working out of the foundation of light and darkness makes it possible to bring the ego into a more optimal incarnation, and therein lies the healing. </p>
                     <p>When light enters darkness, it creates space, bringing us into the third dimension. When we work with color out of its origin in the interaction of light and darkness, we use it differently than we do in soul painting. This is not an illustrative path where we remain with the laws of the outer world; instead, when these laws are reversed in the human being, we go into the being of the color itself. When this occurs, we can see outer color as inner soul movement as the result of the working of light and darkness. </p>
                     <p>We create transparent color space through color perspective as a result of the interaction of light and darkness, rather than line perspective. When colors come into a<strong> </strong>space, they make a place for the ego to come in, and with this the soul world becomes open to the spirit. </p>
                     <blockquote>
                       <blockquote>
                         <p>Our inner organic experiences lead us, although unconsciously, into the world of the three dimensions: the standing upright, the organizing of oneself symmetrically-asymmetrically, the orientation in space. The further continuation is neither organic, nor an abstract mathematical process, it is a reversal into the spiritual. It is through the so-called fourth dimension, which in reality transforms the third dimension, not simply brought back into the plane [but higher &ndash; L.C.]. It also leads into space, but this space is laden with spirit. It is filled with spirit as the three-dimensional space is filled with matter (R. Steiner, 1922, The Hague &ndash; transcribed by Dr. Elisabeth Vreede) (as cited in Collot d&rsquo;Herbois, 1981, p. 75).</p>
                       </blockquote>
                     </blockquote>
                     <p>The healing principle of the ego is often referred to in the writings of other anthroposophical therapies, since it is fundamental to the anthroposophical approach to medicine and the human being, but if we cannot see the ego in the client&rsquo;s pictures, it is not really there for them as part of the therapy. Any art (e.g. music, sculpture, painting, etc.), developed completely enough, could be used to access the whole human being through its particular &ldquo;door.&rdquo; All polarities (warm-cold, convex-concave, etc.) derive from the primordial, original creative polarity of Light and Darkness that connects to the creative forces in the human being (Steiner, 1909/1997).</p>
                   <p>Distinguishing the approach of Painting Therapy from all others is the realization of Light and Darkness as <em>the</em> healing principle. The healing impulse comes through our connection with the Spirit through these creative spiritual principles. As Steiner notes in <em>The Invisible Man Within Us: The Pathology Underlying Therapy,</em> &ldquo;Healing consists of supporting by external means what is already present in the organism as an original healing force.&rdquo;</p>                     </td>
                 </tr>
               </table>
                 <p align="center" class="copyright">&copy; 2007 - by Pamela Whitman &amp; Marielle Levin, Light, Darkness &amp; Color. All rights reserved. </p></td>
             </tr>
            </table>


          </td>
          <td>&nbsp;</td>
          </td>

        </tr>
        <tr>
          <td bgcolor=#403d3c>&nbsp;</td>
          <td width=230 height="50" valign=top bgcolor=#403d3c></td>
          <td width=413>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
    </table>						
</body>

</html>


<p class="footer" style="text-align:left;padding-left:0px">
	
		
</p>
