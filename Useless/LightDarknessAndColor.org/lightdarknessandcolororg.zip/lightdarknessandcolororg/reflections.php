<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<html>
<head>

		<title>Personal reflections on Liane Collot d'Herbois</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	
	    <link href="ldc.css" rel="stylesheet" type="text/css">
	    <script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
</head>								
	<body leftmargin=0 topmargin=0 rightmargin=0 bottommargin=0 onLoad="MM_preloadImages('images/lianne.jpg','images/articles_2.jpg','images/reflections_2.jpg','images/education_2.jpg','images/therapy_2.jpg','images/contact_2.jpg')">
	<table cellspacing=0 cellpadding=0 width=100% height=100% border=0>

        <tr height=75>
          <td bgcolor=#403d3c>&nbsp;</td>
          <td width=230 bgcolor=#403d3c>&nbsp;</td>
          <td width=478>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr height=570>   
          <td bgcolor=403d3c>&nbsp;</td>
          <td colspan=2 valign=top height=570>



             <table width=708 height=570 border=0 align=center cellpadding=0 cellspacing=0 bordercolor="#000000" class="border">
             <tr>
               <td width=708 valign=top bordercolor="#000000" class="body_text"><table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
                 <tr>
                   <td colspan="6"><div align="center"><a href="http://www.lightdarknessandcolor.org/home.php"><img src="images/banner.jpg" alt="Light, Darkness &amp; Color" width="688" height="110" border="0"></a></div></td>
                 </tr>
                 <tr>
                   <td><a href="/liane.php" target="_top" onClick="MM_nbGroup('down','group1','lianne1','',1)" onMouseOver="MM_nbGroup('over','lianne1','images/lianne.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/lianne_1.jpg" alt="Lianne Collot d'Herbois" name="lianne1" width="98" height="55" border="0"></a></td>
                   <td><a href="/articles.php" target="_top" onClick="MM_nbGroup('down','group1','articles1','',1)" onMouseOver="MM_nbGroup('over','articles1','images/articles_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/articles_1.jpg" alt="Articles" name="articles1" width="98" height="55" border="0"></a></td>
                   <td><a href="/reflections.php" target="_top" onClick="MM_nbGroup('down','group1','reflections1','',1)" onMouseOver="MM_nbGroup('over','reflections1','images/reflections_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/reflections_1.jpg" alt="Personal Reflections" name="reflections1" width="98" height="55" border="0"></a></td>
                   <td><a href="/education.php" target="_top" onClick="MM_nbGroup('down','group1','education1','',1)" onMouseOver="MM_nbGroup('over','education1','images/education_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/education_1.jpg" name="education1" width="98" height="55" border="0"></a></td>
                   <td><a href="/painting-therapy.php" target="_top" onClick="MM_nbGroup('down','group1','therapy1','',1)" onMouseOver="MM_nbGroup('over','therapy1','images/therapy_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/therapy_1.jpg" alt="Painting Therapy" name="therapy1" width="98" height="55" border="0"></a></td>
                   <td><a href="/contact.php" target="_top" onClick="MM_nbGroup('down','group1','contact1','',1)" onMouseOver="MM_nbGroup('over','contact1','images/contact_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/contact_1.jpg" alt="Contact" name="contact1" width="98" height="55" border="0"></a></td>
                 </tr>
                 <tr>
                   <td colspan="6" class="body_text"><h1><strong>Personal reflections on Liane Collot d&rsquo;Herbois</strong></h1>
                     Complete texts from Lilipoh article contributors and others who have shared their experiences are included here. If you would like to add your own reflections to this section, please email Marielle Levin &lt;mariellevin@comcast.net&gt; or Pamela Whitman &lt;pamwhitman@yahoo.com&gt;.
                   <p><strong>Jannebeth R&ouml;ell, Portland, Oregon</strong>, &lt;jannebeth@mindspring.com&gt;:<br>
                     I saw an advertisement for a painting class in the brochure from the school of Dr.<br>
                     Hauschka in Boll. In 1966, I applied to the school thinking I would be taught by Dr. Hauschka. Upon arrival I discovered that Liane Collot d&rsquo;Herbois, then at the age of 59, would teach the class. At the time I was not a skilled artist and as this was an advanced painting class, I thought I was totally out of place. Nonetheless, I decided to make the best of it.</p>
                   <p>One morning, Liane would talk about the color red, and her way of teaching let you live in it. The rest of the day the color red would come to your attention. You would see the strawberries in the store, the geraniums in the garden, the reds in the sunset, all with new eyes. It was as if the color red had become alive. She was a guide in the world of color. Every day she would introduce another color and it would stay with you the rest of the day.</p>
                   <p>I can still hear her say in a mix of German and English: &ldquo;A mistake, darling, is not<br>
                     &lsquo;schlimm&rsquo;(bad), but do it &rsquo;nie wieder&rsquo; (never again).&rdquo; Her painting instructions were very confusing and frustrating to follow. For example, she would say, &ldquo;Put a red veil over it darling.&rdquo; I did and found out to late that she meant a veil with openings in it. Then she would say: &ldquo;Oh darling, do not listen to me now, ask me questions when I am on the other side, then listen to me.&rdquo;</p>
                   <p>Liane&rsquo; s paintings were meant as a memory of a Michaelic call from the spiritual<br>
                     world. She loved to talk about her time with Ita Wegman, the physician who worked with Rudolf Steiner at the renewal of medicine, the fundamentals of therapy. It was to Ita Wegman that she dedicated her book Light, darkness and color in painting therapy&ldquo;. This book was written when she was 81, the result of a life long search for the macrocosmic threefold being of light, color and darkness. When I asked her to describe Ita Wegman, Liane paused and her gaze turned inward. She said: &ldquo;A golden Michaelic light, darling.&rdquo;</p>
                   <p><strong>Lois Schroff, San Antonio Tlayacapan, Mexico</strong>, &lt;loiss@prodigy.net.mx&gt;:<br>
                     On my first meeting (1976 in Holland) with Liane Collot d&rsquo;Herbois and her friend<br>
                     Francine van Davalaar, I was treated to a light meal, and a showing of slides of<br>
                     Liane&rsquo;s paintings. Afterward she asked: &ldquo;What do you think?&rdquo; Overwhelmed, I<br>
                     answered, &ldquo;This is the first time I have seen anyone paint with LIGHT.&rdquo; To which<br>
                     she added: &ldquo;and DARKNESS,&rdquo; and proceeded for an hour to tell me about the<br>
                     soul/spiritual foundations of color, according to the philosophy of Rudolf Steiner,<br>
                     Goethe&rsquo;s color theory, and how, in the atmosphere, the light is viridian green and the other colors, darkening, revolve around it (cool colors behind the light and the warm colors in front). She then asked which slide was my favorite, and gave it to me. In my diary I wrote: &ldquo;She is humble, intelligent, honest and open...&rdquo; Her desire was always that &ldquo;the work go further.&rdquo;</p>
                   <p>Later that year I attended her four-day class of fifty painters in Land-en-Bosch,<br>
                     Holland. Because I was about to return to the U.S., after a two-year stay in<br>
                     Europe, I asked if it would be possible to take another class before leaving. They<br>
                     kindly invited me to come to their home in Boxtel, Holland for a week&rsquo;s private<br>
                     tutoring. There I discovered that she loved gardening and cooking, and had a<br>
                     delightful sense of humor.</p>
                   <p>After many years of struggle with the theory and the painting, I wrote A<br>
                     PAINTER&rsquo;S HANDBOOK: EXPERIENCING COLOR BETWEEN DARKNESS AND LIGHT, which Liane edited before it was published. My purpose was to help &ldquo;the work go further.&rdquo; Following Liane&rsquo;s death, when PAINTER&rsquo;S HANDBOOK was out-of-print, the Rudolf Steiner College Press published an expanded version, entitled, COLOR, ITS RELATIONSHIP TO SOUL AND SPIRIT, which contains many of Liane&rsquo;s spiritual insights concerning color.</p>
                   <p>Receiving a letter from Liane, bearing the salutation &ldquo;Dearest Lois,&rdquo; was a<br>
                     cherished event. For my lifetime, Liane was most definitely my chief mentor,<br>
                     inspirer, and muse.</p>
                   <p><strong>Martha Loving Orgain, Alberta, VA</strong>, &lt;lovingcolor@earthlink.net&gt;:<br>
                     During the years between 1993 and 2002, I went to the Netherlands to attend the&nbsp;Painting Therapy Training at&nbsp;Emerald Foundation, Den Haag. It was during part of this time that&nbsp; I worked with Liane Collot d'Herbois, both privately and in the training.&nbsp;Of the many times I visited Liane in her home in Driebergen near Zeist, she talked to me about many things and about painting with plant colors.&nbsp; </p>
                   <p>Her home was humble with lots of books and items that represented the many ways that we see color. I remember a diamond-shaped hanging glass piece that was made of thin gold leaf. One way you looked at it, it was viridian green and when it turned it was magenta. She also showed me how to paint with cochineal. She got out a small lid from a jar and put a few bugs in it, adding a tiny bit of water. Slowly the color changed from a light carmine red, deepening to a rich carmine, and slowly changing to a cool magenta, and eventually to grey and then black. It was amazing to see the transformation in front of my eyes.&nbsp;</p>
                   <p>Liane also stressed that when painting with children that it is important to use plant colors as they are more &quot;alive,&quot; and therefore &quot;enlivening,&quot; than store-bought tube paints. &quot;It doesn't matter that they don't last [are fugitive]; it is the process that is important, dahling.&quot; One of her most remembered phrases is, &quot;'tis a pity, dahling,&quot; exclaiming a response to the woes of the world.</p>
                   <p>Liane&nbsp;was an incredible painter, always humbling herself to say, &quot;I'm not an artist, I am a worker.&quot; Let's remember that she was born in 1907, in a different time when people were much more reserved and didn't brag about their talents. Liane crossed the threshold on 17 September 1999. I was in the Netherlands the following spring. The day they were sprinkling her ashes in an apple orchard, I looked out of the window to see a giant rainbow and knew she was speaking to us from the other side.</p>
                   <p>I, for one, would like very much for more people to have access to seeing more of her work. I feel really fortunate to have known and worked directly with her. She is fondly remembered by me and I can feel her on the other side working with and supporting me in my work all the time. For the incredible gift and legacy she gave to us, I live in gratitude.</p>
                   <p><strong>Helen Chamberlain, Nashville, TN</strong>, &lt;georgianwoodtoys@comcast.net&gt;:<br>
                     On first reading Liane's book, Light, Darkness and Color in Painting Therapy, &quot;the veil&quot; of materiality and cultural expectation around my artistic endeavors was<br>
                     lifted, and poetic reflections of her words around color resonated in joy inside me<br>
                     changing my life forever. Liane, when I met with her, was humble, respectful, joy<br>
                     filled and reverently yielded to spirit, and through the light of her coherence and<br>
                     healing, today leads many souls to connect again to the spiritual world. My artistic work today always reflects her incredible contribution and I try to help others know her in my workshops of the Alchemy of this world of color. Through<br>
                     transformation others can connect the heart and hand with the spiritual realms.<br>
                     Liane's legacy lives on in a renewal of soul forces and gifts of the spirit for our<br>
                     culture today.</p>
                   <p><strong>Iris Sullivan, Fair Oaks, CA</strong>, &lt;ameris@pacbell.net&gt;:<br>
                     When I was 20 I was part of the Mystery Drama's put on by Adam Bittleson and we stopped in Sheffield. On the mantel piece of the house where I stayed were three Easter paintings done by Liane. These paintings moved me so strongly that they changed me in some subtle way. I had already decided to do Art Therapy that year but for one reason and another I had to wait fourteen years to attend Emerald Foundation and there I found Liane's work.</p>
                   <p>In the quiet private meetings with my dear friend Karine Monk and me, Liane would light up and talk about Ita Wegman as if she was right in the room with us. Liane could listen to one as if you really mattered. Her whole presence was worked through with loving sacrifice. I feel so gratefully to Liane.</p>
                   <p><strong>Mary Fisher, Orchard Park, NY</strong>, &lt;mfaf52@earthlink.net&gt;:<br>
                     The main thing I keep coming back to are the concepts of darkness carrying colour and light being destructive yet life giving. Colour arises where light meets darkness. Through the encounter great struggle occurs between light and darkness allowing colour to be born.</p>
                   <p>Even though I don't get to paint as often as I'd like to I am grateful to have the<br>
                     opportunity to paint with others as students or patients. I find this experience to be very calming. </p>
                   <p>When people look at my work, I am often told my work seems to glow and hold a spiritual quality and of a moment of time. Just by following 'the laws' a new way of being is possible. It all feels so natural and simply logical.</p>
                   <p><strong>Carolyn Kraw, Pierport, MI</strong>, &lt;ckpierport@yahoo.com&gt;:<br>
                     The greatest gift I received from Liane's teachings came through Janny Mager in<br>
                     the schooling in Wisconsin. It was a late evening talk Janny gave us explaining how the colors came into being - a kin to the &quot;Occult Science&quot; description of planetary evolutions by R. Steiner. It was eye opening and made &quot;Occult Science&quot; come to life for me as now I had something I could connect it to. </p>
                   <p>The other significant praise I have received for painting in veils as given by Liane to us came from a friend of a Collot painting friend that felt inspired upon our mutual friend&rsquo;s death to come to visit me to purchase some paintings. She returned home and took them to a healing group meeting where she hung them. She called me after and said, &quot;You must keep painting as these paintings had such an effect on the group meeting. Everyone felt they were so healing.&quot; </p>
                   <p>Another time with a cancer patient, I used an exercise that was given by Liane to help patients break through. The patient had just that experience of breaking through after we really worked and worked that painting. She knew just what she had to do - she quit her job and gave herself time to work from home as an architect and continue her own version of healing to help herself heal. And she did!! When I have worked with patients at the Drs. McMullen's clinic in Ann Arbor, I have such a joyful feeling of helping my fellow human beings heal as we see such admirable changes. I give great thanks to Liane for carrying Steiner's ideas into the world, and as well for teaching teachers like Janny to share it further. It is so inspiring!</p>
                   <p><strong>Sally Rutledge, Albuquerque, NM</strong>:<br>
                     Color was the magical thread for this amazing lady. My teacher, Liane&rsquo;s student<br>
                     Dorothea Pierce, shared many deeply moving stories about Liane Collot d&rsquo;Herbois&rsquo; life. There was a brilliantly immense devotion to life in all her work.<br>
                     Liane&rsquo;s use of charcoal studies for darkness and light continue to be a therapeutic gift in my life. It is only natural that I am inspired to share this gleaming of the life movements in color. Working out of color to create form is the art this age needs. Being an artist I now had an anchor. This magic thread of color has permeated my own work as an artist for the last twenty odd years. </p>
                   <p>Although teaching this wisdom is my favorite work, Waldorf teaching, color consultation, interior design, and Lazure wall painting (applying transparent layers of color) are all facets. It is comforting to live within a world of Color so deeply explored by Liane Collot d&rsquo;Herbois.</p>
                   <p>Recently I collaborated with another student of this school of art - Wm. Lanmon<br>
                     studied under Lois Schroff. What we bring to each other really enhances our own<br>
                     understanding. In the future Liane&rsquo;s gift of color study will surely expand and be<br>
                     embraced by more and more artists and therapists.</p></td>
                 </tr>
               </table>
                 <?php
				 include 'http://www.lightdarknessandcolor.org/footer.php';
				 ?>
				 </td>
             </tr>
            </table>


          </td>
          <td>&nbsp;</td>
          </td>

        </tr>
        <tr>
          <td bgcolor=#403d3c>&nbsp;</td>
          <td width=230 height="50" valign=top bgcolor=#403d3c></td>
          <td width=413>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
    </table>						
</body>

</html>


<p class="footer" style="text-align:left;padding-left:0px">
	
		
</p>
