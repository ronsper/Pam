<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<html>
<head>

		<title>Liane Collot d'Herbois Life and Work</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	
	    <link href="ldc.css" rel="stylesheet" type="text/css">
	    <script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
</head>								
	<body leftmargin=0 topmargin=0 rightmargin=0 bottommargin=0 onLoad="MM_preloadImages('images/lianne.jpg','images/articles_2.jpg','images/reflections_2.jpg','images/education_2.jpg','images/therapy_2.jpg','images/contact_2.jpg')">
	<table cellspacing=0 cellpadding=0 width=100% height=100% border=0>

        <tr height=75>
          <td bgcolor=#403d3c>&nbsp;</td>
          <td width=230 bgcolor=#403d3c>&nbsp;</td>
          <td width=478>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr height=570>   
          <td bgcolor=403d3c>&nbsp;</td>
          <td colspan=2 valign=top height=570>



             <table width=708 height=570 border=0 align=center cellpadding=0 cellspacing=0 bordercolor="#000000" class="border">
             <tr>
               <td width=708 valign=top bordercolor="#000000" class="body_text"><table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
                 <tr>
                   <td colspan="6"><div align="center"><a href="http://www.lightdarknessandcolor.org/home.php"><img src="images/banner.jpg" alt="Light, Darkness &amp; Color" width="688" height="110" border="0"></a></div></td>
                 </tr>
                 <tr>
                   <td><a href="/liane.php" target="_top" onClick="MM_nbGroup('down','group1','lianne1','',1)" onMouseOver="MM_nbGroup('over','lianne1','images/lianne.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/lianne_1.jpg" alt="Lianne Collot d'Herbois" name="lianne1" width="98" height="55" border="0"></a></td>
                   <td><a href="/articles.php" target="_top" onClick="MM_nbGroup('down','group1','articles1','',1)" onMouseOver="MM_nbGroup('over','articles1','images/articles_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/articles_1.jpg" alt="Articles" name="articles1" width="98" height="55" border="0"></a></td>
                   <td><a href="/reflections.php" target="_top" onClick="MM_nbGroup('down','group1','reflections1','',1)" onMouseOver="MM_nbGroup('over','reflections1','images/reflections_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/reflections_1.jpg" alt="Personal Reflections" name="reflections1" width="98" height="55" border="0"></a></td>
                   <td><a href="/education.php" target="_top" onClick="MM_nbGroup('down','group1','education1','',1)" onMouseOver="MM_nbGroup('over','education1','images/education_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/education_1.jpg" name="education1" width="98" height="55" border="0"></a></td>
                   <td><a href="/painting-therapy.php" target="_top" onClick="MM_nbGroup('down','group1','therapy1','',1)" onMouseOver="MM_nbGroup('over','therapy1','images/therapy_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/therapy_1.jpg" alt="Painting Therapy" name="therapy1" width="98" height="55" border="0"></a></td>
                   <td><a href="/contact.php" target="_top" onClick="MM_nbGroup('down','group1','contact1','',1)" onMouseOver="MM_nbGroup('over','contact1','images/contact_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/contact_1.jpg" alt="Contact" name="contact1" width="98" height="55" border="0"></a></td>
                 </tr>
                 <tr>
                   <td colspan="6" class="body_text"><h1><strong>An Overview of the Life and Work of Liane Collot d&rsquo;Herbois</strong></h1>
                   &copy;Pamela Whitman 2007
                   <p>(This article is a continuation of the introductory paragraph, shown here in italic, from the <a href="home.php">Homepage</a>.)</p>
                     <p><em>Liane Collot d&rsquo;Herbois (1907-1999), born near Tintagel, Cornwall, England, of Scottish and French parentage, encountered the spiritual scientific work of Rudolf Steiner as a young professionally trained artist. She experienced Anthroposophy as the bridge between the spiritual world and practical life. She took up Steiner&rsquo;s work on color, emphasizing light and darkness, and made it visible and workable.</em> She developed it by actually applying the creative forces of light and darkness in painting, both artistically and therapeutically. The result is the dynamic meeting of light and darkness creating <em>movement,</em> which manifests as visible color in a <em>transparent color space</em>. Collot d&rsquo;Herbois was the first to characterize these movements of color and create out of light and darkness a color space that is transparent, breaking through the solid, flat, closed boundaries of colored forms and planes, making it possible to see into and through the color space of the picture. </p>
                     <p>The field of Anthroposophical medicine was developed through Rudolf Steiner&rsquo;s close collaboration with the Dutch physician Dr. Ita Wegman (1876-1943). Their co-authored book, <em>Extending Practical Medicine </em>(formerly <em>Fundamentals of Therapy</em>)<em>, </em>is an extension of the art of healing through spiritual knowledge, providing a more complete picture of the human being, and thereby, the possibility for truly effective and innovative therapeutic approaches. Elisa M&eacute;trailler, who wrote the Foreword to <em>Light, Darkness and Color in Painting Therapy</em>, noted how Collot d&rsquo;Herbois&rsquo; early work with people of all ages showed her tremendous talent for seeing how constitution, temperament and illness can be revealed in one&rsquo;s paintings. Collot d&rsquo;Herbois worked closely with Ita Wegman and other physicians, developing her insights into a Painting Therapy based on the foundation of Anthroposophy.</p>
                     <p>Collot d&rsquo;Herbois also pursued her own artistic work, though she considered herself more a &ldquo;painter&rdquo; than an &ldquo;artist&rdquo; in the more popular sense. She sought to create &ldquo;healing paintings&rdquo; through portraying windows to the spiritual world. This task requires work on oneself and understanding of the true Beings of Color, arising out of the meeting of Light and Darkness. In her book <em>Colour, Part One, </em>Collot d&rsquo;Herbois explains that through the use of the resulting laws of Light, Color and Darkness, one can move beyond subjectivity into a world of greater objective significance. Painting approached in this way can have a therapeutic and freeing effect on the viewer.</p>
                     <p>With the help of the Dutch painter and sculptor Francine van Davelaar (died 1984), she traveled through Europe and America, teaching and painting. She eventually settled in Holland, where she founded the &ldquo;Magenta Group&rdquo; for the painters who had gathered around her, sharing her discourses on the origins of color between light and darkness. This painting group provided the focus for her more artistic contributions, which resulted in her books <em>Colour, Part One </em>and <em>Colour, Part Two.</em></p>
                     <p>In November 1978, Collot d&rsquo;Herbois was asked by the Dutch physician Dr. Paolo Walburgh Schmidt and painting therapist Josine Hutchison, to present her work on the use of color in therapeutic painting. She shared her knowledge and experience of color in relation to light and darkness in Painting Therapy to a core group of therapists and doctors. This endeavor then expanded to include others interested in really taking up her theoretical and practical work. The collaboration eventually resulted in the publication of her book <em>Light, Darkness and Colour in Painting Therapy </em>(1993, 2000).</p>
                     <p>Two members of this group, the Dutch physician Dr. Paul Hutchison and painting therapist Josine Hutchison, were asked by Collot d&rsquo;Herbois herself, as well as therapists from Holland and abroad,<strong> </strong>to create a training for therapists. Courses began in 1986 and developed into a school in 1988 to offer a four-year training in Painting Therapy. The Emerald Foundation, in The Hague, Holland, founded in November 1988, was the first school recognized by the Medical Section of the School of Spiritual Science in Dornach, Switzerland, for offering an approved training in the Painting Therapy approach of Collot d&rsquo;Herbois. Other schools, in Paris, Switzerland, and East Troy, Wisconsin, have also provided training in the principles of Light, Darkness and Color, as well as their artistic and therapeutic application. Individuals trained in this work offer a variety of independent classes and workshops, especially in the artistic aspects. Painting therapists work individually with clients with a wide range of conditions, including physical, in consultation with their doctor when possible.</p>
                   <p>Collot d&rsquo;Herbois made extraordinary contributions toward the understanding of Light, Color and Darkness, showing their direct connection to the human being. Her therapeutic insights and transformative paintings have inspired doctors, therapists, artists, and those seeking a connection with spirit all over the world.</p>
                   </td>
                 </tr>
               </table>
                 <?php
				 include 'http://www.lightdarknessandcolor.org/footer.php';
				 ?>
				 </td>
             </tr>
            </table>


          </td>
          <td>&nbsp;</td>
          </td>

        </tr>
        <tr>
          <td bgcolor=#403d3c>&nbsp;</td>
          <td width=230 height="50" valign=top bgcolor=#403d3c></td>
          <td width=413>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
    </table>						
</body>

</html>


<p class="footer" style="text-align:left;padding-left:0px">
	
		
</p>
