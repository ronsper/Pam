<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<html>
<head>

		<title>Light Darkness and Color Painting Therapy Published Articles</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	
	    <link href="ldc.css" rel="stylesheet" type="text/css">
	    <script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
</head>								
	<body leftmargin=0 topmargin=0 rightmargin=0 bottommargin=0 onLoad="MM_preloadImages('images/lianne.jpg','images/articles_2.jpg','images/reflections_2.jpg','images/education_2.jpg','images/therapy_2.jpg','images/contact_2.jpg')">
	<table cellspacing=0 cellpadding=0 width=100% height=100% border=0>

        <tr height=75>
          <td bgcolor=#403d3c>&nbsp;</td>
          <td width=230 bgcolor=#403d3c>&nbsp;</td>
          <td width=478>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr height=570>   
          <td bgcolor=403d3c>&nbsp;</td>
          <td colspan=2 valign=top height=570>



             <table width=708 height=570 border=0 align=center cellpadding=0 cellspacing=0 bordercolor="#000000" class="border">
             <tr>
               <td width=708 valign=top bordercolor="#000000" class="body_text"><table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
                 <tr>
                   <td colspan="6"><div align="center"><a href="http://www.lightdarknessandcolor.org/home.php"><img src="images/banner.jpg" alt="Light, Darkness &amp; Color" width="688" height="110" border="0"></a></div></td>
                 </tr>
                 <tr>
                   <td><a href="/liane.php" target="_top" onClick="MM_nbGroup('down','group1','lianne1','',1)" onMouseOver="MM_nbGroup('over','lianne1','images/lianne.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/lianne_1.jpg" alt="Lianne Collot d'Herbois" name="lianne1" width="98" height="55" border="0"></a></td>
                   <td><a href="/articles.php" target="_top" onClick="MM_nbGroup('down','group1','articles1','',1)" onMouseOver="MM_nbGroup('over','articles1','images/articles_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/articles_1.jpg" alt="Articles" name="articles1" width="98" height="55" border="0"></a></td>
                   <td><a href="/reflections.php" target="_top" onClick="MM_nbGroup('down','group1','reflections1','',1)" onMouseOver="MM_nbGroup('over','reflections1','images/reflections_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/reflections_1.jpg" alt="Personal Reflections" name="reflections1" width="98" height="55" border="0"></a></td>
                   <td><a href="/education.php" target="_top" onClick="MM_nbGroup('down','group1','education1','',1)" onMouseOver="MM_nbGroup('over','education1','images/education_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/education_1.jpg" name="education1" width="98" height="55" border="0"></a></td>
                   <td><a href="/painting-therapy.php" target="_top" onClick="MM_nbGroup('down','group1','therapy1','',1)" onMouseOver="MM_nbGroup('over','therapy1','images/therapy_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/therapy_1.jpg" alt="Painting Therapy" name="therapy1" width="98" height="55" border="0"></a></td>
                   <td><a href="/contact.php" target="_top" onClick="MM_nbGroup('down','group1','contact1','',1)" onMouseOver="MM_nbGroup('over','contact1','images/contact_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/contact_1.jpg" alt="Contact" name="contact1" width="98" height="55" border="0"></a></td>
                 </tr>
                 <tr>
                   <td colspan="6" class="body_text"><h1>Light Darkness and Color Painting Therapy Published Articles </h1>
                   <p>The following article appears in the Fall 2007 issue of <strong>&ldquo;Lilipoh&rdquo; </strong>magazine:</p>
                     <h2><strong>A Celebration of Liane Collot d&rsquo;Herbois </strong></h2>
                     &copy; Pamela Whitman and Marielle Levin 2007<br>
                       <br>
                       In celebration of the 100th anniversary of the birth of Liane Collot d&rsquo;Herbois in Cornwall, England in 1907, we would like to share insights collected from some of those in America who knew Liane and her work. Their experiences offer a glimpse into the being of this remarkable individual.
                     <p>At the age of 21, Liane graduated from college with a degree in art and education and was searching for a new approach to painting. Her study of Goethe&rsquo;s color theory and Rudolf Steiner&rsquo;s spiritual science became the basis of her research into the laws of Light, Darkness and Color. She worked closely with Dr. Ita Wegman, who collaborated with Rudolf Steiner to establish anthroposophical medicine. She became Liane&rsquo;s mentor and encouraged her to develop her art as a way to bring healing. Liane created paintings for those who were ill and developed her insights into a groundbreaking method of therapeutic painting that relates to the whole human being. In 1978, she was asked to share her innovative work with therapists and physicians, which she did in Holland until her death in 1999.</p>
                     <p>Beginning in 1964, Liane traveled on several occasions to the US. She initially came with her co-worker, Francine van Davelaar, at the invitation of Anne Stockton, to give painting workshops, as well as to paint murals for the city of Los Angeles. Many years later, she brought her approach to therapeutic painting. </p>
                     <p>Mary Ellen Wilby, Fair Oaks, CA, who attended that first workshop, recounts, &ldquo;the pictures were a path of initiation.&rdquo; A room full of people would fall immediately quiet in Liane&rsquo;s presence. Dorothea Pierce, Massachusetts, studied extensively with Liane and became one of the foremost pioneers of her work in America. She convinced Liane that &ldquo;there were people who could now distinguish &lsquo;soul-painting&rsquo; from a totally new spiritual painting based on cosmic laws of light and dark &ndash; which the genius of Collot had shown us.&rdquo; Liane&rsquo;s books Colour, Part I and II, resulted from this impulse. </p>
                     <p>Jannebeth R&ouml;ell, Portland, OR, attended the school of Dr. Hauschka in Boll, Germany, in 1966, when Liane, then 59, taught the painting class. &ldquo;One morning, Liane would talk about the color red, and her way of teaching let you live in it. The rest of the day the color red would come to your attention. You would see (it)&hellip; all with new eyes. It was as if the color red had become alive. She was a guide in the world of color.&rdquo; </p>
                     <p>Julie Moyer, Fair Oaks, CA shares that Liane was an enigmatic teacher. Jannebeth corroborates that her instructions were sometimes confusing, to which Liane replied: &lsquo;Oh darling, do not listen to me now; ask me questions when I am on the other side &ndash; then listen to me.&rsquo;&rdquo; Now, those of us working with her indications on Light, Darkness and Color experience the task and possibility of these words.<br>
                         <br>
                       Jannebeth notes, &ldquo;It was to Ita Wegman that she dedicated her book Light, Darkness and Colour in Painting Therapy. This book was written when she was 81, the result of a life-long search for the macrocosmic threefold being of light, color and darkness.&rdquo; </p>
                     <p>Lois Schroff, San Antonio Tlayacapan, Mexico: &ldquo;On my first meeting with Liane in 1976, &hellip; I was treated to a showing of slides of Liane&rsquo;s paintings.  Afterwards she asked, &lsquo;What do you think?&rsquo; Overwhelmed, I answered, &lsquo;This is the first time I have seen anyone paint with LIGHT,&rsquo; to which she added &lsquo;and DARKNESS.&rsquo; She proceeded for an hour to tell me about the soul/spiritual foundations of colors&hellip; and how in the atmosphere the light is viridian green and the other colors, darkening, revolve around it (cool colors behind the light and warm colors in front)&hellip; She was humble, intelligent, honest and open&hellip; Her desire was always &lsquo;that the work go further.&rsquo;&rdquo;</p>
                     <p>Martha Loving Orgain, Alberta, VA: &ldquo;Liane stressed that when painting with children it is important to use plant colors as they are more &lsquo;alive,&rsquo; and therefore &lsquo;enlivening,&rsquo; than store-bought tube paints. &lsquo;It doesn&rsquo;t matter that they don&rsquo;t last (are fugitive), it is the process that is important.&rsquo;&rdquo;</p>
                     <p>Helen Chamberlain, Nashville, TN: &ldquo;Liane was humble, respectful, joy-filled and reverently yielded to spirit, and through the light of her coherence and healing, today leads many souls to connect again to the spiritual world.&rdquo;</p>
                     <p>Iris Sullivan, Fair Oaks, CA: &ldquo;Liane could listen to one as if you really mattered. Her whole presence was worked through with loving sacrifice.&rdquo;</p>
                     <p>Dorothea Pierce relates, &ldquo;As Frau Dr. Hauschka told me, &lsquo;Liane is a genius.&rsquo; And, as Rudolf Steiner pointed out more than once: Thousands had seen the old church lamp swinging, but it took Galileo&rsquo;s genius to observe and discover the laws of the pendulum for modern science.  Similarly, Collot&rsquo;s genius has discovered the laws of Light, Color and Darkness with careful observation and conscious thinking.&rdquo;</p>
                     <p>&ldquo;Whether it was a person, a painting, a flower, or a color, Collot could put herself aside and completely enter the other in knowing that other. She often said that in seeing color, &lsquo;there is no inner and outer.&rsquo; This can be a way of life if one is conscious enough, and strong enough, with everything one meets.&rdquo;</p>
                     <p>For complete texts from these and other contributors, please click on the <a href="/reflections.php">Personal Reflections tab</a>. For information about workshops and schooling in Light, Darkness and Color and Painting Therapy, click on the <a href="/education.php">Education tab</a>.</p>
                     <p><em>Marielle Levin and Pamela Whitman, M.A., both certified Painting Therapists, are collaborating on an initiative to create a school for the work of Collot d'Herbois in America.</em></p>
                   </td>
                 </tr>
               </table>
                 <?php
				 include 'http://www.lightdarknessandcolor.org/footer.php';
				 ?>
				 </td>
             </tr>
            </table>


          </td>
          <td>&nbsp;</td>
          </td>

        </tr>
        <tr>
          <td bgcolor=#403d3c>&nbsp;</td>
          <td width=230 height="50" valign=top bgcolor=#403d3c></td>
          <td width=413>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
    </table>						
</body>

</html>


<p class="footer" style="text-align:left;padding-left:0px">
	
		
</p>
