<style type="text/css">
<!--
.style_footer {
	color: #403D3C;
	font-size: 10 pt;
	font-family: Geneva, Arial, Helvetica, sans-serif;
	background-position: center;
}


-->
</style>
  <span class="style_footer">
  <div align="center">
    <p><br />
      <a href="http://lightdarknessandcolor.org/home.php">LDC Home</a> | <a href="http://lightdarknessandcolor.org/liane.php">Liane Collot d'Herbois </a> |  <a href="http://lightdarknessandcolor.org/articles.php">Articles</a> | <a href="http://lightdarknessandcolor.org/reflections.php">Personal Reflections </a> | <a href="http://lightdarknessandcolor.org/educations.php">Education</a> | <a href="http://lightdarknessandcolor.org/painting-therapy.php">Painting Therapy </a> | <a href="http://lightdarknessandcolor.org/contact.php">Contact</a> <br />
&copy; 2007 - 2008  by Pamela Whitman &amp; Marielle Levin, Light, Darkness &amp; Color. All rights reserved. </p>
  </div>
  