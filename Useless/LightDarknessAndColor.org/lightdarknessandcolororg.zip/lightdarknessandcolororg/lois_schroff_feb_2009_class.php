<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<html>
<head>

		<title>Lois Schroff Feb 2009 Veil Painting Class Mexico</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
	
	    <link href="ldc.css" rel="stylesheet" type="text/css">
	    <script type="text/JavaScript">
<!--
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}

function MM_findObj(n, d) { //v4.01
  var p,i,x;  if(!d) d=document; if((p=n.indexOf("?"))>0&&parent.frames.length) {
    d=parent.frames[n.substring(p+1)].document; n=n.substring(0,p);}
  if(!(x=d[n])&&d.all) x=d.all[n]; for (i=0;!x&&i<d.forms.length;i++) x=d.forms[i][n];
  for(i=0;!x&&d.layers&&i<d.layers.length;i++) x=MM_findObj(n,d.layers[i].document);
  if(!x && d.getElementById) x=d.getElementById(n); return x;
}

function MM_nbGroup(event, grpName) { //v6.0
  var i,img,nbArr,args=MM_nbGroup.arguments;
  if (event == "init" && args.length > 2) {
    if ((img = MM_findObj(args[2])) != null && !img.MM_init) {
      img.MM_init = true; img.MM_up = args[3]; img.MM_dn = img.src;
      if ((nbArr = document[grpName]) == null) nbArr = document[grpName] = new Array();
      nbArr[nbArr.length] = img;
      for (i=4; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
        if (!img.MM_up) img.MM_up = img.src;
        img.src = img.MM_dn = args[i+1];
        nbArr[nbArr.length] = img;
    } }
  } else if (event == "over") {
    document.MM_nbOver = nbArr = new Array();
    for (i=1; i < args.length-1; i+=3) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = (img.MM_dn && args[i+2]) ? args[i+2] : ((args[i+1])? args[i+1] : img.MM_up);
      nbArr[nbArr.length] = img;
    }
  } else if (event == "out" ) {
    for (i=0; i < document.MM_nbOver.length; i++) {
      img = document.MM_nbOver[i]; img.src = (img.MM_dn) ? img.MM_dn : img.MM_up; }
  } else if (event == "down") {
    nbArr = document[grpName];
    if (nbArr)
      for (i=0; i < nbArr.length; i++) { img=nbArr[i]; img.src = img.MM_up; img.MM_dn = 0; }
    document[grpName] = nbArr = new Array();
    for (i=2; i < args.length-1; i+=2) if ((img = MM_findObj(args[i])) != null) {
      if (!img.MM_up) img.MM_up = img.src;
      img.src = img.MM_dn = (args[i+1])? args[i+1] : img.MM_up;
      nbArr[nbArr.length] = img;
  } }
}
//-->
</script>
</head>								
	<body leftmargin=0 topmargin=0 rightmargin=0 bottommargin=0 onLoad="MM_preloadImages('images/lianne.jpg','images/articles_2.jpg','images/reflections_2.jpg','images/education_2.jpg','images/therapy_2.jpg','images/contact_2.jpg')">
	<table cellspacing=0 cellpadding=0 width=100% height=100% border=0>

        <tr height=75>
          <td bgcolor=#403d3c>&nbsp;</td>
          <td width=230 bgcolor=#403d3c>&nbsp;</td>
          <td width=478>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
        <tr height=570>   
          <td bgcolor=403d3c>&nbsp;</td>
          <td colspan=2 valign=top height=570>



             <table width=708 height=570 border=0 align=center cellpadding=0 cellspacing=0 bordercolor="#000000" class="border">
             <tr>
               <td width=708 valign=top bordercolor="#000000" class="body_text"><table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
                 <tr>
                   <td colspan="6"><div align="center"><a href="http://www.lightdarknessandcolor.org/home.php"><img src="images/banner.jpg" alt="Light, Darkness &amp; Color" width="688" height="110" border="0"></a></div></td>
                 </tr>
                 <tr>
                   <td><a href="/liane.php" target="_top" onClick="MM_nbGroup('down','group1','lianne1','',1)" onMouseOver="MM_nbGroup('over','lianne1','images/lianne.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/lianne_1.jpg" alt="Lianne Collot d'Herbois" name="lianne1" width="98" height="55" border="0"></a></td>
                   <td><a href="/articles.php" target="_top" onClick="MM_nbGroup('down','group1','articles1','',1)" onMouseOver="MM_nbGroup('over','articles1','images/articles_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/articles_1.jpg" alt="Articles" name="articles1" width="98" height="55" border="0"></a></td>
                   <td><a href="/reflections.php" target="_top" onClick="MM_nbGroup('down','group1','reflections1','',1)" onMouseOver="MM_nbGroup('over','reflections1','images/reflections_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/reflections_1.jpg" alt="Personal Reflections" name="reflections1" width="98" height="55" border="0"></a></td>
                   <td><a href="/education.php" target="_top" onClick="MM_nbGroup('down','group1','education1','',1)" onMouseOver="MM_nbGroup('over','education1','images/education_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/education_1.jpg" name="education1" width="98" height="55" border="0"></a></td>
                   <td><a href="/painting-therapy.php" target="_top" onClick="MM_nbGroup('down','group1','therapy1','',1)" onMouseOver="MM_nbGroup('over','therapy1','images/therapy_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/therapy_1.jpg" alt="Painting Therapy" name="therapy1" width="98" height="55" border="0"></a></td>
                   <td><a href="/contact.php" target="_top" onClick="MM_nbGroup('down','group1','contact1','',1)" onMouseOver="MM_nbGroup('over','contact1','images/contact_2.jpg','',1)" onMouseOut="MM_nbGroup('out')"><img src="images/contact_1.jpg" alt="Contact" name="contact1" width="98" height="55" border="0"></a></td>
                 </tr>
                 <tr>
                   <td colspan="6" class="body_text"><h1> Lois Schroff&rsquo;s&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; February, 2009&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Watercolor Veil-painting Classes </h1>
                   <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <em>On the Pacific Ocean at Barra de Navidad, Mexico</em></p>
                     <p><img src="images/lois_schroff_class.JPG" alt="lois-schroff-class" width="684" height="513"> </p>
                     <p> &ldquo;Veil-painting,&rdquo; for those of you unfamiliar with the term, is sometimes referred to as &ldquo;glazing&rdquo; and is a  particular technique whereby the paper is stretched on a wooden frame in class, making for a taut surface on  which to apply multiple layers (veils) of watercolor onto dry paper. I learned&nbsp; this technique, combined with  Goethe&rsquo;s color theory, when I studied painting therapy in Holland with Liane Collot d&rsquo;Herbois.&nbsp; (See my book, <em>Color, its Relationship to Soul and Spirit</em>* or my DVD, <em>Spirit in Watercolor</em>**). </p>
                     <p> Please go to <a rel="nofollow" href="http://www.alondrahotel.com" target="_blank"> <u>www.alondrahotel.com</u> </a> &nbsp;(corrected) to view the hotel where I have reserved rooms in my name at  their Casa Club on the ocean.&nbsp; Across the street is their five-story hotel where we will hold our classes on the  covered rooftop (magnificent views).&nbsp; There will be a separate room where our art supplies can be stored each  night.&nbsp; Class size is limited, so reserve early.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </p>
                     <p> The classes begin Monday, February 9 at 9:00am and end at 2:00pm each day, continuing through Friday,  February 13. Plan to arrive at least by Sunday, Feb. 8 and depart Saturday, February 14 (or later, depending on  your preference and availability of space).&nbsp; My fee for the week is $300 and the hotel charge is $144/night (if  shared, $72/night).&nbsp; Reserve your room through me as I have already arranged for five double rooms and will  request more (or longer times) if needed.&nbsp; This will be the high season so the earlier you reserve, the more likely  we are to get additional days.&nbsp; </p>
                     <p> Weather in February is delightful&mdash;80-degree days, 60s at night--little rain.&nbsp; I recommend summertime  beachwear, hat, and a windbreaker.&nbsp; Shoes can be flip-flops, but stable enough to withstand cobblestones and  broken sidewalks--whatever is comfortable for you.&nbsp; We do a lot of standing while painting, so please consider  that.&nbsp; Of course, there are many interesting things to buy--jewelry, clothes, and handmade artisanias.&nbsp; We can  also take a few interesting side trips. </p>
                     <p> Airfares, taxis, tips, food, drinks and painting supplies are additional expenses.&nbsp; If coming from outside Mexico,  you will need a Passport.&nbsp; The closest airport is Manzanillo.&nbsp; When I checked fares and times on Priceline.com,  it appeared that Continental offers the best schedule and price.&nbsp; The airport is not far from Barra.&nbsp; Taxis are  about $35US or $350 pesos--less if you share.&nbsp; Ask the price before getting into the taxi.&nbsp; Your credit card is  acceptable at the hotel, but at very few other places.&nbsp; This is a cash society.&nbsp; Bring Traveler&rsquo;s Checks in $100  denominations, and cash one at the airport for pesos to get you started.&nbsp; I recommend trip insurance.&nbsp; Because, if  I have to cancel the workshop, I will not take responsibility for the cost of flights you may have booked. When I  have your check (the amount depending on your length of stay and whether or not you want to share or have a  private room) I will e-mail the supply list. To reserve, please send $300 plus hotel room cost, made payable to  me, to my PO Box:&nbsp; 5802 Bob Bullock C1, Unit 328-C 104, Laredo, TX 78041. Questions? e-mail me at <a rel="nofollow" href="mailto:loiss@prodigy.net.mx" target="_blank"> <u>loiss@prodigy.net.mx</u> </a> , or call me at my Virginia Vonage number, 703/880-8831.&nbsp; Upon request, there will be a  full refund (less $50 handling fee) prior to December 1, and half refund (less $50 handling fee) between 12/1  and 12/15.&nbsp; After 12/15/08, refunds only if your spot can be filled by someone else, or in case I cancel the class. </p>
                     <p> &nbsp;&nbsp;&nbsp;&nbsp; I look forward to seeing you in Mexico.&nbsp; Lois </p>                     <h1>&nbsp;</h1>
                   </td>
                 </tr>
               </table>
                 <?php
				 include 'http://www.lightdarknessandcolor.org/footer.php';
				 ?>
				 </td>
             </tr>
            </table>


          </td>
          <td>&nbsp;</td>
          </td>

        </tr>
        <tr>
          <td bgcolor=#403d3c>&nbsp;</td>
          <td width=230 height="50" valign=top bgcolor=#403d3c></td>
          <td width=413>&nbsp;</td>
          <td>&nbsp;</td>
        </tr>
    </table>						
</body>

</html>


<p class="footer" style="text-align:left;padding-left:0px">
	
		
</p>
